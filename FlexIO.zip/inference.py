import torch
import torchaudio
import argparse
import os

def overlap_add_inference(model: torch.nn.Module, 
                          mixture: torch.Tensor, 
                          chunk_size: int = 32000, 
                          step_size: int = 16000) -> torch.Tensor:
    
    audio_length = mixture.shape[-1]
    
    # Calculate how much padding is needed to perfectly fit the last chunk
    if (audio_length - chunk_size) % step_size != 0:
        pad_size = step_size - ((audio_length - chunk_size) % step_size)
        mixture = torch.nn.functional.pad(mixture, (0, pad_size))
        
    padded_length = mixture.shape[-1]
    
    output_audio = None 
    overlap_count = None
    
    model.eval()
    with torch.no_grad():
        for start_idx in range(0, padded_length - chunk_size + 1, step_size):
            end_idx = start_idx + chunk_size
            chunk = mixture[:, start_idx:end_idx]
            
            # Forward pass: Expected output shape (1, num_speakers, chunk_size)
            separated_chunk = model(chunk)
            
            # Initialize the output buffer dynamically based on model's channel output
            if output_audio is None:
                num_speakers = separated_chunk.shape[1]
                output_audio = torch.zeros((num_speakers, padded_length), device=mixture.device)
                overlap_count = torch.zeros((1, padded_length), device=mixture.device)
            
            # Applying a Hanning window here instead of a flat 1.0 improves crossfade smoothness
            window = torch.hann_window(chunk_size, device=mixture.device)
            
            # Additively stack the overlapping windows
            output_audio[:, start_idx:end_idx] += separated_chunk.squeeze(0) * window
            overlap_count[:, start_idx:end_idx] += window

    # Normalize the audio by dividing by the overlap counter
    output_audio = output_audio / (overlap_count + 1e-8)
    
    # Trim the padding to return the exact original length
    return output_audio[:, :audio_length]

def main():
    parser = argparse.ArgumentParser(description="Multi-Speaker Separation Inference")
    parser.add_argument("--input_wav", type=str, required=True, help="Path to mixed audio file")
    parser.add_argument("--output_dir", type=str, default="./outputs", help="Output directory")
    parser.add_argument("--sample_rate", type=int, default=8000, help="Target sample rate")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # Load mixture
    mixture, sr = torchaudio.load(args.input_wav)
    if sr != args.sample_rate:
        resampler = torchaudio.transforms.Resample(orig_freq=sr, new_freq=args.sample_rate)
        mixture = resampler(mixture)
    
    # Move to mono if it's stereo
    if mixture.shape[0] > 1:
        mixture = torch.mean(mixture, dim=0, keepdim=True)
    
    mixture = mixture.to(device)

    
    # Placeholder for compilation testing
    class DummyModel(torch.nn.Module):
        def forward(self, x):
            # Outputs 3 identical channels as a dummy placeholder
            return x.unsqueeze(1).repeat(1, 3, 1) 
            
    model = DummyModel().to(device)

    print(f"Processing: {args.input_wav}")
    separated_tracks = overlap_add_inference(model, mixture, chunk_size=32000, step_size=16000)
    
    os.makedirs(args.output_dir, exist_ok=True)
    
    for i in range(separated_tracks.shape[0]):
        out_path = os.path.join(args.output_dir, f"speaker_{i+1}.wav")
        # Ensure we write out within standard audio ranges [-1.0, 1.0]
        track = separated_tracks[i].cpu().unsqueeze(0)
        track = track / torch.max(torch.abs(track)) 
        
        torchaudio.save(out_path, track, args.sample_rate)
        print(f"Saved: {out_path}")

if __name__ == "__main__":
    main()